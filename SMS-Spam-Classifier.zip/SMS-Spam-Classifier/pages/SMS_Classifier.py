from pathlib import Path
import re

import joblib
import nltk
import pandas as pd
import streamlit as st
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

BASE_DIR = Path(__file__).resolve().parent.parent

st.set_page_config(
    page_title="SMS Classifier | Signal",
    page_icon="✳",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap');
    :root { --ink:#192522; --muted:#68736e; --paper:#f3f5f0; --line:#dce2da; --mint:#c8efdc; --green:#176b50; --coral:#e46f51; }
    .stApp { color:var(--ink); background:radial-gradient(ellipse at 84% 0%, #e1eee2 0, transparent 35%), var(--paper); font-family:'DM Sans',sans-serif; }
    [data-testid="stHeader"] { background:transparent; }
    .block-container { max-width:1040px; padding-top:2.1rem; padding-bottom:4rem; }
    h1, h2, h3 { color:var(--ink); font-family:'Fraunces',Georgia,serif; letter-spacing:0 !important; }
    h1 { font-size:3rem !important; }
    .eyebrow, .metric-label { font-family:'DM Mono',monospace; text-transform:uppercase; letter-spacing:.08em; font-size:.72rem; color:var(--muted); }
    .hero { border-bottom:1px solid var(--line); padding:.3rem 0 1.7rem; margin-bottom:1.4rem; }
    .hero p { color:var(--muted); max-width:680px; margin:-.65rem 0 0; font-size:1.05rem; }
    .metric { min-height:112px; padding:1rem 1.1rem; border:1px solid var(--line); border-radius:6px; background:rgba(255,255,255,.66); }
    .metric-value { font-family:'Fraunces',Georgia,serif; font-size:2.2rem; line-height:1.25; margin-top:.4rem; }
    .result { padding:1.1rem 1.3rem; border-radius:4px; margin-top:1.2rem; }
    .result.spam { background:#fbe3da; border-left:5px solid var(--coral); }
    .result.ham { background:var(--mint); border-left:5px solid var(--green); }
    .result h3 { margin:.3rem 0 .2rem; font-size:1.9rem; }
    .result p { margin:0; }
    .stButton > button { background:var(--green); color:#fff; border:0; border-radius:4px; padding:.55rem 1.1rem; }
    .stButton > button:hover { background:#124f3b; color:#fff; }
    div[data-testid="stSidebar"] { background:rgba(255,255,255,.55); }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def load_assets():
    try:
        stopwords.words("english")
    except LookupError:
        nltk.download("stopwords", quiet=True)
    model = joblib.load(BASE_DIR / "ML_model.pkl")
    vectorizer = joblib.load(BASE_DIR / "Vectorizer.pkl")
    return model, vectorizer, PorterStemmer(), set(stopwords.words("english"))


@st.cache_data
def load_dataset():
    df = pd.read_csv(BASE_DIR / "ham_spam.csv", encoding="latin-1")[["v1", "v2"]].copy()
    df.columns = ["label", "message"]
    return df.dropna(subset=["label", "message"])


try:
    model, vectorizer, stemmer, stop_words = load_assets()
    data = load_dataset()
except Exception as error:
    st.error(f"Could not load the model or dataset: {error}")
    st.info("Keep ML_model.pkl, Vectorizer.pkl and ham_spam.csv in the project folder.")
    st.stop()


def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"https?://\S+|www\.\S+", "", text)
    text = re.sub(r"[^a-zA-Z]", " ", text)
    return " ".join(stemmer.stem(w) for w in text.split() if w not in stop_words)


def classify(messages):
    vectors = vectorizer.transform([clean_text(m) for m in messages])
    probabilities = model.predict_proba(vectors)
    spam_index = list(model.classes_).index(1)
    return [(p[spam_index] >= 0.5, max(p)) for p in probabilities]


n_total = len(data)
n_ham = int((data["label"] == "ham").sum())
n_spam = int((data["label"] == "spam").sum())

st.markdown(
    '<div class="hero"><div class="eyebrow">SMS SECURITY / LIVE CLASSIFIER</div>'
    "<h1>Read the signal.</h1>"
    "<p>Check a suspicious text, scan a whole message list, or get a quick view of the training data.</p></div>",
    unsafe_allow_html=True,
)

for column, label, value in zip(
    st.columns(3),
    ["Training messages", "Legitimate", "Spam examples"],
    [f"{n_total:,}", f"{n_ham:,}", f"{n_spam:,}"],
):
    with column:
        st.markdown(
            f'<div class="metric"><div class="metric-label">{label}</div>'
            f'<div class="metric-value">{value}</div></div>',
            unsafe_allow_html=True,
        )

tab_check, tab_batch, tab_data = st.tabs(["Check a message", "Batch scan", "Dataset"])

with tab_check:
    st.subheader("One message, one clear read")
    message = st.text_area(
        "Message", height=180, label_visibility="collapsed",
        placeholder="Paste an SMS message here...",
    )
    if st.button("Check message"):
        if not message.strip():
            st.warning("Please enter a message first.")
        else:
            is_spam, confidence = classify([message])[0]
            kind, title, note = (
                ("spam", "Likely spam", "Treat links and requests with care.")
                if is_spam
                else ("ham", "Likely legitimate", "No strong spam signals detected.")
            )
            st.markdown(
                f'<div class="result {kind}"><div class="eyebrow">Classification · {confidence * 100:.1f}% confidence</div>'
                f"<h3>{title}</h3><p>{note}</p></div>",
                unsafe_allow_html=True,
            )

with tab_batch:
    st.subheader("Scan a list of messages")
    st.caption("Enter one message per line, or upload a CSV/TXT file.")
    batch_text = st.text_area("Messages", height=180, label_visibility="collapsed",
                              placeholder="One message per line...", key="batch_text")
    upload = st.file_uploader("Upload CSV or TXT", type=["csv", "txt"])
    messages = [line.strip() for line in batch_text.splitlines() if line.strip()]
    if upload is not None:
        if upload.name.lower().endswith(".csv"):
            frame = pd.read_csv(upload, encoding="latin-1")
            column = "message" if "message" in frame.columns else frame.columns[-1]
            messages += frame[column].dropna().astype(str).tolist()
        else:
            messages += [l.strip() for l in upload.read().decode("latin-1").splitlines() if l.strip()]
    if st.button("Scan messages"):
        if not messages:
            st.warning("Add at least one message to scan.")
        else:
            results = classify(messages)
            out = pd.DataFrame({
                "message": messages,
                "result": ["Spam" if r[0] else "Legitimate" for r in results],
                "confidence": [f"{r[1] * 100:.1f}%" for r in results],
            })
            st.write(f"**{(out['result'] == 'Spam').sum()}** of {len(out)} messages flagged as spam.")
            st.dataframe(out, hide_index=True)
            st.download_button("Download results (CSV)", out.to_csv(index=False), "scan_results.csv", "text/csv")

with tab_data:
    st.subheader("Training data at a glance")
    st.bar_chart(data["label"].value_counts().rename({"ham": "Legitimate", "spam": "Spam"}))
    choice = st.selectbox("Show examples", ["All", "ham", "spam"])
    shown = data if choice == "All" else data[data["label"] == choice]
    st.dataframe(shown.head(50), hide_index=True)
