from pathlib import Path
from html import escape
import re
import xml.etree.ElementTree as ET
import zipfile

import streamlit as st


BASE_DIR = Path(__file__).resolve().parent
REPORT_PATH = BASE_DIR / "Report on SMS classifier.txt"
SECTION_TITLES = (
    "Introduction",
    "Methodology",
    "Results, Applications and Conclusion",
)

st.set_page_config(
    page_title="SMS Spam Classifier | Project Report",
    page_icon="✳",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap');

    :root {
        --ink: #192522;
        --muted: #68736e;
        --paper: #f3f5f0;
        --line: #dce2da;
        --mint: #c8efdc;
        --green: #176b50;
        --coral: #e46f51;
    }
    .stApp {
        color: var(--ink);
        background: radial-gradient(ellipse at 84% 0%, #e1eee2 0, transparent 35%), var(--paper);
        font-family: 'DM Sans', sans-serif;
    }
    [data-testid="stHeader"] { background: transparent; }
    .block-container { max-width: 1040px; padding-top: 2.1rem; padding-bottom: 4rem; }
    h1, h2, h3 { color: var(--ink); }
    h1 { font-family: 'Fraunces', Georgia, serif; font-size: 3rem !important; letter-spacing: 0 !important; }
    h2 { font-family: 'Fraunces', Georgia, serif; letter-spacing: 0 !important; }
    p, label, [data-testid="stMarkdownContainer"] { letter-spacing: 0 !important; }
    .eyebrow, .metric-label {
        font-family: 'DM Mono', monospace;
        text-transform: uppercase;
        letter-spacing: .08em;
        font-size: .72rem;
        color: var(--muted);
    }
    .hero { border-bottom: 1px solid var(--line); padding: .3rem 0 1.7rem; margin-bottom: 1.4rem; }
    .hero p { color: var(--muted); max-width: 680px; margin: -.65rem 0 0; font-size: 1.05rem; }
    .metric {
        min-height: 112px;
        padding: 1rem 1.1rem;
        border: 1px solid var(--line);
        border-radius: 6px;
        background: rgba(255,255,255,.66);
    }
    .metric-value { font-family: 'Fraunces', Georgia, serif; font-size: 1.65rem; line-height: 1.25; margin-top: .55rem; }
    .report-section { border-top: 1px solid var(--line); padding-top: 1.1rem; margin-top: 1.6rem; }
    .report-copy { max-width: 850px; color: var(--ink); line-height: 1.75; }
    .report-copy strong { color: var(--green); }
    div[data-testid="stSidebar"] { background: rgba(255,255,255,.55); }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_data
def load_report():
    try:
        with zipfile.ZipFile(REPORT_PATH) as document:
            root = ET.fromstring(document.read("word/document.xml"))
        namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        paragraphs = [
            "".join(node.text or "" for node in paragraph.findall(".//w:t", namespace)).strip()
            for paragraph in root.findall(".//w:p", namespace)
        ]
        return [paragraph for paragraph in paragraphs if paragraph]
    except zipfile.BadZipFile:
        return [line.strip() for line in REPORT_PATH.read_text(encoding="utf-8").splitlines() if line.strip()]


def format_report_text(text):
    text = re.sub(r"([.!?])(?=(?:Objectives|Software|Dataset|Workflow|Example Predictions|Advantages|Applications|Future Scope|Conclusion):)", r"\1\n\n", text)
    for label in (
        "Objectives",
        "Software",
        "Dataset",
        "Workflow",
        "Example Predictions",
        "Advantages",
        "Applications",
        "Future Scope",
        "Conclusion",
    ):
        text = text.replace(f"{label}:", f"\n\n**{label}**\n")
    text = text.replace("• ", "\n- ")
    return text


try:
    report_paragraphs = load_report()
except (OSError, ET.ParseError, KeyError, zipfile.BadZipFile) as error:
    st.error(f"The project report could not be opened: {error}")
    st.info("Keep Report on SMS classifier.txt in the project folder.")
    st.stop()

if not report_paragraphs:
    st.error("The project report is empty.")
    st.stop()

title = report_paragraphs[0]
sections = {}
current_section = None
for paragraph in report_paragraphs[1:]:
    if paragraph in SECTION_TITLES:
        current_section = paragraph
        sections[current_section] = []
    elif current_section:
        sections[current_section].append(paragraph)

st.markdown(
    f'<div class="hero"><div class="eyebrow">PROJECT REPORT / SMS SECURITY</div>'
    f'<h1>{escape(title)}</h1>'
    '<p>A machine-learning approach to separating unwanted SMS from genuine messages.</p></div>',
    unsafe_allow_html=True,
)

metrics = st.columns(3)
for column, label, value in zip(
    metrics,
    ["Reported accuracy", "Training split", "Text features"],
    ["~98%", "80 / 20", "TF-IDF · 5,000"],
):
    with column:
        st.markdown(
            f'<div class="metric"><div class="metric-label">{label}</div>'
            f'<div class="metric-value">{value}</div></div>',
            unsafe_allow_html=True,
        )

for heading in SECTION_TITLES:
    content = sections.get(heading, [])
    if content:
        st.markdown('<div class="report-section"></div>', unsafe_allow_html=True)
        st.subheader(heading)
        for paragraph in content:
            st.markdown(format_report_text(paragraph))
